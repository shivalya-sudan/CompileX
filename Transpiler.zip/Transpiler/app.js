


// ==================== EXAMPLE CODE ====================
const EXAMPLES = {
    hello: `// Simple Hello World
DISPLAY("Hello, World!")`,

    variables: `// Working with variables
SET x TO 10
SET y TO 20
SET sum TO x + y
DISPLAY("Sum:", sum)`,

    loop: `// For Loop Example
FOR i IN RANGE(1, 5) {
  DISPLAY("Count:", i)
}`,

    conditional: `// If-Else Example
SET age TO 18
IF age >= 18 {
  DISPLAY("You are an adult")
} ELSE {
  DISPLAY("You are a minor")
}`,

    list: `// Working with Lists
SET fruits TO LIST["apple", "banana", "cherry"]
DISPLAY(fruits)
APPEND fruits: "orange"
DISPLAY(fruits)`,

    function: `// Function Definition
FUNCTION greet(name) {
  DISPLAY("Hello, " + name)
}
greet("Alice")`,

    whileLoop: `// While Loop
SET count TO 0
WHILE count < 5 {
  DISPLAY(count)
  SET count TO count + 1
}`
};

const DOCS = `SYNTAX GUIDE

SET variable TO value
  Assigns a value to a variable
  Example: SET x TO 10

DISPLAY(arg1, arg2, ...)
  Prints values to the console
  Example: DISPLAY("Hello", x)

INPUT(prompt)
  Reads user input
  Example: SET name TO INPUT("Enter name: ")

IF condition { statements } ELSE { statements }
  Conditional execution
  Example: IF x > 5 { DISPLAY("Big") } ELSE { DISPLAY("Small") }

WHILE condition { statements }
  Loop while condition is true
  Example: WHILE x < 10 { SET x TO x + 1 }

FOR variable IN iterable { statements }
  Loop over iterable
  Example: FOR i IN RANGE(1, 5) { DISPLAY(i) }

FUNCTION name(params) { statements }
  Define a function
  Example: FUNCTION add(a, b) { RETURN a + b }

RETURN value
  Return from function
  Example: RETURN x + y

LIST[elements]
  Create a list
  Example: SET items TO LIST[1, 2, 3]

RANGE(start, end)
  Create a range
  Example: FOR i IN RANGE(0, 10) { ... }

LENGTH(collection)
  Get length of collection
  Example: SET len TO LENGTH(items)

APPEND list: value
  Add to list
  Example: APPEND items: 42

REMOVE list: index
  Remove from list
  Example: REMOVE items: 0

Operators: + - * / % == != < > <= >=
Logical: AND OR NOT`;



let appState = {
    sourceCode: EXAMPLES.hello,
    compiledCode: '',
    error: null,
    isCompiling: false,
    activeTab: 'editor',
    showDocs: false,
    selectedExample: 'hello',
};

// Auto-compile on load
let autoCompiled = false;       

let compileTimeout;

function getElements() {
    return {
        root: document.getElementById('root'),
        sourceCode: document.getElementById('sourceCode'),
        compiledCode: document.getElementById('compiledCode'),
        errorBox: document.getElementById('errorBox'),
        successBox: document.getElementById('successBox'),
        tabButtons: document.querySelectorAll('.tab-button'),
        tabContents: document.querySelectorAll('.tab-current'),
        docsPanel: document.getElementById('docsPanel'),
        exampleBtns: document.querySelectorAll('.example-btn'),
        docsButton: document.getElementById('docsButton'),
        compileButton: document.getElementById('compileButton'),
        resetButton: document.getElementById('resetButton'),    
        copyButton: document.getElementById('copyButton'),  
        executeButton: document.getElementById('executeButton'),

    };
}

function render() {
    const root = document.getElementById('root');
    root.innerHTML = getHtml();
    attachEventListeners();
}

function getHtml() {
    const docsHtml = appState.showDocs ? `
    <div class = "panel docs-panel animate-slide-down">
        <div class = "panel-header">
        <h2 class = "panel-title">Syntax Guide</h2>
        <button class ="close-btn" id="closeDocsBtn">x</button>
        </div>
        <div class = "docs-grid">
            ${DOCS.split('\n\n').slice(0,6).map(section => `
                <div class ="docs-section">${escapeHtml(section)}</div>
                `).join('') }
                </div>
            </div>
` : '';
const editorTabHtml = `
<div class="editor-layout">
    <div class="animate-fade-in">
        <div class= "panel">
            <div class="panel-header">
                <h2 class="panel-title">Pseudo code</h2>
                </div>
                <textarea id="sourceCode" class="editor-input" 
                placeholder="Write your pseudocode here..." spellcheck="false">${escapeHtml(appState.sourceCode)}</textarea>
                <div style="display: flex; gap: 12px; margin-top: 15px">
                <button id="compileButton" class="btn btn-primary">
                <span>▶︎</span> Compile and Run
                </button>
                <button id="resetButton" class= "btn btn-secondary">
                <span>↻</span> Reset 
                </button>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar animate-fade-in" style="animation-delay: 0.2s;">
                <div class="panel" style="height: 100%;">
                <h3 class="panel-title" style="margin-bottom: 16px;">Examples</h3>
                <div class="example-list">
                    ${Object.entries(EXAMPLES).map(([key,_]) => `
                        <button class="example-btn ${appState.selectedExample == key ? 'active' : ''}" data-example="${key}">
                        ${key.charAt(0).toUpperCase()+key.slice(1).replace(/([A-Z])/g, ' $1')
}
                        </button>
                        `).join('')}
                    </div>
                </div>
            </div>
        </div>
    `;

    const outputTabHtml = `
        <div class="animate-fade-in">
        ${appState.error ? `
            <div class="error-box">
                <div class="error-icon">⚠</div>
                <div class="error-content">
                <h3>Compilation Error</h3>
                <p>${escapeHtml(appState.error)}</p>
                </div>
                </div>
                `: appState.compiledCode ? `
                <div class="success-box">✓ Compiled successfully</div>
            `: ''}
        
            ${appState.compiledCode ? `
                <div class="panel">
                    <div class="panel-header">
                        <h2 class="panel-title">Python Code</h2>
                        <div class="panel-actions">
                         <button id="copyButton" class="btn btn-secondary btn-small">
                            <span>📋</span>
                            </button>
                            <button id="executeButton" class="btn btn-primary btn-small">
                            <span>▶︎</span> Execute
                            </button>
                        </div>
                    </div>
                    <div class="code-block" id="compiledCode">${escapeHtml(appState.compiledCode)}</div>
                </div>
            `: ''}
        </div>
    `;

    const examplesTabHtml = `
        <div class="animate-fade-in">
            <div class="examples-grid">
                ${Object.entries(EXAMPLES).map(([key, code]) => `
                    <div class="example-card">
                        <div class="panel" style="flex: 1; display: flex; flex-direction: column;">
                            <h3 class="panel-title" style="margin-bottom: 12px;">
                            ${key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
                            </h3>
                            <div class="code-block" style="flex: 1; margin-bottom: 12px;">${escapeHtml(code)}</div>
                            <button class="btn btn-primary btn-small example-btn" data-example="${key}">
                            Load Example
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    return `
        ${docsHtml}
        
        <!--Header-->
        <div class="header">
            <div class="header-container">
                <div class="header-title">
                    <h1>PseudoCode Compiler</h1>
                    <p>Write English-like code, get Python output</p>
                </div>
                <div class="header-buttons">
                    <button id="docsButton" class="btn btn-secondary">
                    <span>📖</span> Docs
                    </button>
                </div>
            </div>
        </div>

        <!--Main content-->
        <div class="main-content">
        <div class="tabs">
            <button class="tab-button ${appState.activeTab === 'editor' ? 'active' : ''}" data-tab="editor">Editor</button>
            
            <button class="tab-button ${appState.activeTab === 'output' ? 'active' : ''}" data-tab="output">Output</button>
            
            <button class="tab-button ${appState.activeTab === 'examples' ? 'active' : ''}" data-tab="examples">Examples</button>
        </div>

        <!--Tab contents-->  

        <div class="tab-content ${appState.activeTab === 'editor' ? 'active' : ''}" id="editorTab">
            ${editorTabHtml}
        </div>
        <div class="tab-content ${appState.activeTab === 'output' ? 'active' : ''}" id="outputTab">
            ${outputTabHtml}
        </div>
        <div class="tab-content ${appState.activeTab === 'examples' ? 'active' : ''}" id="examplesTab">
            ${examplesTabHtml}
        </div>
    </div>
    `;
}

//                   EVENT HANDLERS

function attachEventListeners() {
    document.querySelectorAll('[data-tab]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const tabName = e.currentTarget.dataset.tab;
            appState.activeTab = tabName;
            render();
        });
    });
    
    //Source code for input handlers
    const sourceCodeElem = document.getElementById('sourceCode');
    if (sourceCodeElem) {
        sourceCodeElem.addEventListener('input', (e) => {
            appState.sourceCode = e.target.value;
            clearTimeout(compileTimeout);
            compileTimeout = setTimeout(handleCompile, 800);
        });
    }

    // For compile Button
    const compileBtn= document.getElementById('compileButton');
    if (compileBtn) {
        compileBtn.addEventListener('click', handleCompile);
    }

    //Reset Button
    const resetBtn = document.getElementById('resetButton');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            appState.sourceCode = EXAMPLES[appState.selectedExample];
            appState.compiledCode = '';
            appState.error = null;
            render();
        });
    }

    //Copy Button
    const copyBtn = document.getElementById('copyButton');
    if (copyBtn) {
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(appState.compiledCode);
        });
    }
    
    //Execute Button
    const executeBtn = document.getElementById('executeButton');
    if (executeBtn) {
        executeBtn.addEventListener('click', handleExecute);
    }

    //Docs Button
    const docsBtn = document.getElementById('docsButton');
    if (docsBtn) {
        docsBtn.addEventListener('click', () => {
            appState.showDocs = !appState.showDocs;
            render();
        });
    }

    //Close Docs Button
        const closeDocsBtn = document.getElementById('closeDocsBtn');
        if(closeDocsBtn) {
            closeDocsBtn.addEventListener('click',()=> {
                appState.showDocs = false;
                render();
            });
        }

    // Example Buttons in sidebar
    document.querySelectorAll('[data-example]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const exampleKey = e.currentTarget.dataset.example;
            appState.selectedExample = exampleKey;
            appState.sourceCode = EXAMPLES[exampleKey];
            appState.compiledCode = '';
            appState.error = null;
            render();
            handleCompile();
        });
    });
}

function handleExecute() {
    if(!appState.compiledCode) {
        handleCompile();
        return;
    }

    const originalLog = console.log;
    let output = '';

    try {
        console.log = function(...args) {
            output += args.join('') + '\n';
            originalLog.apply(console, args);
        };

        new Function(appState.compiledCode)();

        console.log = originalLog;

        if(output.trim()) {
            alert(`Output:\n\n\n${output}`);
        } else {
            alert('Code executed successfully with no output.');
        }
    } catch (e) {
        console.log = originalLog;
        appState.error = `Execution Error: ${e.message}`;
        render();
    }
}   

//                  COMPILE HANDLER

function handleCompile() {
    try {
        const result = compile(appState.sourceCode);
        if (result.success) {
            appState.compiledCode = result.code;
            appState.error = null;
        } else {
            appState.error = result.error;
            appState.compiledCode = '';
        }
    } catch (e) {
        appState.error = e.message;
        appState.compiledCode = '';
    }
    render();
}

//                  UTILITY FUNCTIONS

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}


//          INITIALIZATION

document.addEventListener('DOMContentLoaded', () => {
    // First render to set up UI
    render();
    // Auto-compile the initial example
    setTimeout(() => {
        if (!autoCompiled) {
            handleCompile();
            autoCompiled = true;
        }
    }, 100);
});
