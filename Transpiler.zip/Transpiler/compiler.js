// ==================== TOKEN ====================
class Token {
    constructor(type, value, line, column) {
        this.type = type;
        this.value = value;
        this.line = line;
        this.column = column;
    }
}

// ==================== LEXER ====================
class Lexer {
    constructor(source) {
        this.source = source;
        this.position = 0;
        this.line = 1;
        this.column = 1;
        this.tokens = [];
    }

    error(message) {
        throw new Error(`Lexer Error at line ${this.line}, column ${this.column}: ${message}`);
    }

    peek(offset = 0) {
        return this.source[this.position + offset] || null;
    }

    advance() {
        const char = this.source[this.position];
        this.position++;
        if (char === '\n') {
            this.line++;
            this.column = 1;
        } else {
            this.column++;
        }
        return char;
    }

    skipWhitespace() {
        while (this.peek() && /\s/.test(this.peek())) {
            this.advance();
        }
    }

    skipComment() {
        if (this.peek() === '/' && this.peek(1) === '/') {
            while (this.peek() && this.peek() !== '\n') {
                this.advance();
            }
        }
    }

    readString(quote) {
        const startLine = this.line;
        const startCol = this.column;
        let value = '';
        this.advance(); // opening quote

        while (this.peek() && this.peek() !== quote) {
            if (this.peek() === '\\') {
                this.advance();
                const escapeChar = this.advance();
                const escapeMap = {
                    n: '\n',
                    t: '\t',
                    r: '\r',
                    '\\': '\\',
                    '"': '"',
                    "'": "'"
                };
                value += escapeMap[escapeChar] || escapeChar;
            } else {
                value += this.advance();
            }
        }

        if (!this.peek()) {
            this.error(`Unterminated string starting at line ${startLine}, column ${startCol}`);
        }
        this.advance(); // closing quote
        return value;
    }

    readNumber() {
        let value = '';
        while (this.peek() && /[0-9.]/.test(this.peek())) {
            value += this.advance();
        }
        return value;
    }

    readIdentifier() {
        let value = '';
        while (this.peek() && /[a-zA-Z0-9_]/.test(this.peek())) {
            value += this.advance();
        }
        return value;
    }

        tokenize() {
        const keywords = {
            SET: 'SET',
            TO: 'TO',
            DISPLAY: 'DISPLAY',
            INPUT: 'INPUT',
            IF: 'IF',
            ELSE: 'ELSE',
            WHILE: 'WHILE',
            FOR: 'FOR',
            IN: 'IN',
            FUNCTION: 'FUNCTION',
            RETURN: 'RETURN',
            TRUE: 'TRUE',
            FALSE: 'FALSE',
            AND: 'AND',
            OR: 'OR',
            NOT: 'NOT',
            LIST: 'LIST',
            RANGE: 'RANGE',
            APPEND: 'APPEND',
            REMOVE: 'REMOVE',
            LENGTH: 'LENGTH',
            OPEN: 'OPEN',
            READ: 'READ',
            WRITE: 'WRITE',
            CLOSE: 'CLOSE',
            FROM: 'FROM',
            IMPORT: 'IMPORT',
            AS: 'AS'
        };

        while (this.position < this.source.length) {
            this.skipWhitespace();

            if (this.position >= this.source.length) break;

            if (this.peek() === '/' && this.peek(1) === '/') {
                this.skipComment();
                continue;
            }

            const line = this.line;
            const column = this.column;

            if (this.peek() === '"' || this.peek() === "'") {
                const quote = this.peek();
                const value = this.readString(quote);
                this.tokens.push(new Token('STRING', value, line, column));
            } else if (/[0-9]/.test(this.peek())) {
                const value = this.readNumber();
                this.tokens.push(new Token('NUMBER', value, line, column));
            } else if (/[a-zA-Z_]/.test(this.peek())) {
                const value = this.readIdentifier();
                const type = keywords[value.toUpperCase()] || 'IDENTIFIER';
                this.tokens.push(new Token(type, value, line, column));
            } else {
                const char = this.peek();
                if (char === '(') {
                    this.advance();
                    this.tokens.push(new Token('LPAREN', '(', line, column));
                } else if (char === ')') {
                    this.advance();
                    this.tokens.push(new Token('RPAREN', ')', line, column));
                } else if (char === '[') {
                    this.advance();
                    this.tokens.push(new Token('LBRACKET', '[', line, column));
                } else if (char === ']') {
                    this.advance();
                    this.tokens.push(new Token('RBRACKET', ']', line, column));
                } else if (char === '{') {
                    this.advance();
                    this.tokens.push(new Token('LBRACE', '{', line, column));
                } else if (char === '}') {
                    this.advance();
                    this.tokens.push(new Token('RBRACE', '}', line, column));
                } else if (char === ',') {
                    this.advance();
                    this.tokens.push(new Token('COMMA', ',', line, column));
                } else if (char === ':') {
                    this.advance();
                    this.tokens.push(new Token('COLON', ':', line, column));
                } else if (char === '=' && this.peek(1) === '=') {
                    this.advance();
                    this.advance();
                    this.tokens.push(new Token('EQ', '==', line, column));
                } else if (char === '!' && this.peek(1) === '=') {
                    this.advance();
                    this.advance();
                    this.tokens.push(new Token('NEQ', '!=', line, column));
                } else if (char === '<' && this.peek(1) === '=') {
                    this.advance();
                    this.advance();
                    this.tokens.push(new Token('LTE', '<=', line, column));
                } else if (char === '>' && this.peek(1) === '=') {
                    this.advance();
                    this.advance();
                    this.tokens.push(new Token('GTE', '>=', line, column));
                } else if (char === '<') {
                    this.advance();
                    this.tokens.push(new Token('LT', '<', line, column));
                } else if (char === '>') {
                    this.advance();
                    this.tokens.push(new Token('GT', '>', line, column));
                } else if (char === '+') {
                    this.advance();
                    this.tokens.push(new Token('PLUS', '+', line, column));
                } else if (char === '-') {
                    this.advance();
                    this.tokens.push(new Token('MINUS', '-', line, column));
                } else if (char === '*') {
                    this.advance();
                    this.tokens.push(new Token('MULT', '*', line, column));
                } else if (char === '/') {
                    this.advance();
                    this.tokens.push(new Token('DIV', '/', line, column));
                } else if (char === '%') {
                    this.advance();
                    this.tokens.push(new Token('MOD', '%', line, column));
                } else if (char === '.') {
                    this.advance();
                    this.tokens.push(new Token('DOT', '.', line, column));
                } else {
                    this.error(`Unexpected character: ${char}`);
                }
            }
        }

        this.tokens.push(new Token('EOF', null, this.line, this.column));
        return this.tokens;
    }
}

// ==================== PARSER ====================
class Parser {
    constructor(tokens) {
        this.tokens = tokens;
        this.position = 0;
    }

    error(message) {
        const token = this.peek();
        throw new Error(`Parser Error at line ${token.line}, column ${token.column}: ${message}`);
    }

    peek(offset = 0) {
        return this.tokens[this.position + offset] || this.tokens[this.tokens.length - 1];
    }

    advance() {
        return this.tokens[this.position++];
    }

    expect(type) {
        if (this.peek().type !== type) {
            this.error(`Expected ${type}, got ${this.peek().type}`);
        }
        return this.advance();
    }

    parse() {
        const statements = [];
        while (this.peek().type !== 'EOF') {
            statements.push(this.parseStatement());
        }
        return { type: 'Program', statements };
    }

    parseStatement() {
        switch (this.peek().type) {
            case 'SET':
                return this.parseAssignment();
            case 'DISPLAY':
                return this.parseDisplay();
            case 'INPUT':
                return this.parseInput();
            case 'IF':
                return this.parseIf();
            case 'WHILE':
                return this.parseWhile();
            case 'FOR':
                return this.parseFor();
            case 'FUNCTION':
                return this.parseFunction();
            case 'RETURN':
                return this.parseReturn();
            case 'IMPORT':
                return this.parseImport();
            case 'OPEN':
                return this.parseFileOpen();
            case 'READ':
                return this.parseRead();
            case 'WRITE':
                return this.parseWrite();
            case 'CLOSE':
                return this.parseFileClose();
            case 'APPEND':
                return this.parseAppend();
            case 'REMOVE':
                return this.parseRemove();
            default:
                this.error(`Unexpected statement: ${this.peek().type}`);
        }
    }

    parseAssignment() {
        this.expect('SET');
        const name = this.expect('IDENTIFIER').value;
        this.expect('TO');
        const value = this.parseExpression();
        return { type: 'Assignment', name, value };
    }

    parseDisplay() {
        this.expect('DISPLAY');
        const args = this.parseArgumentList();
        return { type: 'Display', args };
    }

    parseInput() {
        this.expect('INPUT');
        const prompt = this.peek().type === 'STRING' ? this.parseExpression() : null;
        return { type: 'Input', prompt };
    }

    parseIf() {
        this.expect('IF');
        const condition = this.parseExpression();
        this.expect('LBRACE');
        const thenBranch = this.parseBlock();
        this.expect('RBRACE');

        let elseBranch = null;
        if (this.peek().type === 'ELSE') {
            this.expect('ELSE');
            this.expect('LBRACE');
            elseBranch = this.parseBlock();
            this.expect('RBRACE');
        }

        return { type: 'If', condition, thenBranch, elseBranch };
    }

    parseWhile() {
        this.expect('WHILE');
        const condition = this.parseExpression();
        this.expect('LBRACE');
        const body = this.parseBlock();
        this.expect('RBRACE');
        return { type: 'While', condition, body };
    }

    parseFor() {
        this.expect('FOR');
        const variable = this.expect('IDENTIFIER').value;
        this.expect('IN');
        const iterable = this.parseExpression();
        this.expect('LBRACE');
        const body = this.parseBlock();
        this.expect('RBRACE');
        return { type: 'For', variable, iterable, body };
    }

    parseFunction() {
        this.expect('FUNCTION');
        const name = this.expect('IDENTIFIER').value;
        this.expect('LPAREN');
        const params = [];
        while (this.peek().type !== 'RPAREN') {
            params.push(this.expect('IDENTIFIER').value);
            if (this.peek().type === 'COMMA') {
                this.advance();
            }
        }
        this.expect('RPAREN');
        this.expect('LBRACE');
        const body = this.parseBlock();
        this.expect('RBRACE');
        return { type: 'Function', name, params, body };
    }

    parseReturn() {
        this.expect('RETURN');
        const value = this.peek().type === 'RBRACE' || this.peek().type === 'EOF' ? null : this.parseExpression();
        return { type: 'Return', value };
    }

    parseImport() {
        this.expect('IMPORT');
        const module = this.expect('IDENTIFIER').value;
        let alias = module;
        if (this.peek().type === 'AS') {
            this.expect('AS');
            alias = this.expect('IDENTIFIER').value;
        }
        return { type: 'Import', module, alias };
    }

    parseFileOpen() {
        this.expect('OPEN');
        const filename = this.parseExpression();
        this.expect('AS');
        const variable = this.expect('IDENTIFIER').value;
        const mode = this.peek().type === 'STRING' ? this.parseExpression() : { type: 'Literal', value: 'r' };
        return { type: 'FileOpen', filename, variable, mode };
    }

    parseRead() {
        this.expect('READ');
        const file = this.expect('IDENTIFIER').value;
        return { type: 'Read', file };
    }

    parseWrite() {
        this.expect('WRITE');
        const file = this.expect('IDENTIFIER').value;
        this.expect('COLON');
        const content = this.parseExpression();
        return { type: 'Write', file, content };
    }

    parseFileClose() {
        this.expect('CLOSE');
        const file = this.expect('IDENTIFIER').value;
        return { type: 'Close', file };
    }

    parseAppend() {
        this.expect('APPEND');
        const list = this.expect('IDENTIFIER').value;
        this.expect('COLON');
        const value = this.parseExpression();
        return { type: 'Append', list, value };
    }

    parseRemove() {
        this.expect('REMOVE');
        const list = this.expect('IDENTIFIER').value;
        this.expect('COLON');
        const index = this.parseExpression();
        return { type: 'Remove', list, index };
    }

    parseBlock() {
        const statements = [];
        while (this.peek().type !== 'RBRACE' && this.peek().type !== 'EOF') {
            statements.push(this.parseStatement());
        }
        return statements;
    }

    parseArgumentList() {
        const args = [];
        if (this.peek().type !== 'LPAREN') {
            return args;
        }
        this.expect('LPAREN');
        while (this.peek().type !== 'RPAREN') {
            args.push(this.parseExpression());
            if (this.peek().type === 'COMMA') {
                this.advance();
            }
        }
        this.expect('RPAREN');
        return args;
    }

    parseExpression() {
        return this.parseOr();
    }

    parseOr() {
        let left = this.parseAnd();
        while (this.peek().type === 'OR') {
            this.advance();
            const right = this.parseAnd();
            left = { type: 'BinaryOp', op: 'OR', left, right };
        }
        return left;
    }

    parseAnd() {
        let left = this.parseComparison();
        while (this.peek().type === 'AND') {
            this.advance();
            const right = this.parseComparison();
            left = { type: 'BinaryOp', op: 'AND', left, right };
        }
        return left;
    }

    parseComparison() {
        let left = this.parseAdditive();
        const compOps = ['EQ', 'NEQ', 'LT', 'GT', 'LTE', 'GTE'];
        while (compOps.includes(this.peek().type)) {
            const op = this.advance().type;
            const right = this.parseAdditive();
            left = { type: 'BinaryOp', op, left, right };
        }
        return left;
    }

    parseAdditive() {
        let left = this.parseMultiplicative();
        while (this.peek().type === 'PLUS' || this.peek().type === 'MINUS') {
            const op = this.advance().type;
            const right = this.parseMultiplicative();
            left = { type: 'BinaryOp', op, left, right };
        }
        return left;
    }

    parseMultiplicative() {
        let left = this.parseUnary();
        while (this.peek().type === 'MULT' || this.peek().type === 'DIV' || this.peek().type === 'MOD') {
            const op = this.advance().type;
            const right = this.parseUnary();
            left = { type: 'BinaryOp', op, left, right };
        }
        return left;
    }

    parseUnary() {
        if (this.peek().type === 'NOT') {
            this.advance();
            const expr = this.parseUnary();
            return { type: 'UnaryOp', op: 'NOT', expr };
        }
        if (this.peek().type === 'MINUS') {
            this.advance();
            const expr = this.parseUnary();
            return { type: 'UnaryOp', op: 'MINUS', expr };
        }
        return this.parsePostfix();
    }

    parsePostfix() {
        let expr = this.parsePrimary();

        while (true) {
            if (this.peek().type === 'DOT') {
                this.advance();
                const method = this.expect('IDENTIFIER').value;
                if (this.peek().type === 'LPAREN') {
                    const args = this.parseArgumentList();
                    expr = { type: 'MethodCall', object: expr, method, args };
                } else {
                    expr = { type: 'PropertyAccess', object: expr, property: method };
                }
            } else if (this.peek().type === 'LBRACKET') {
                this.advance();
                const index = this.parseExpression();
                this.expect('RBRACKET');
                expr = { type: 'IndexAccess', object: expr, index };
            } else if (this.peek().type === 'LPAREN' && expr.type === 'Identifier') {
                const args = this.parseArgumentList();
                expr = { type: 'FunctionCall', name: expr.name, args };
            } else {
                break;
            }
        }

        return expr;
    }

    parsePrimary() {
        if (this.peek().type === 'NUMBER') {
            const value = this.advance().value;
            return { type: 'Literal', value: value.includes('.') ? parseFloat(value) : parseInt(value) };
        }

        if (this.peek().type === 'STRING') {
            const value = this.advance().value;
            return { type: 'Literal', value };
        }

        if (this.peek().type === 'TRUE') {
            this.advance();
            return { type: 'Literal', value: true };
        }

        if (this.peek().type === 'FALSE') {
            this.advance();
            return { type: 'Literal', value: false };
        }

        if (this.peek().type === 'LIST') {
            this.advance();
            this.expect('LBRACKET');
            const elements = [];
            while (this.peek().type !== 'RBRACKET') {
                elements.push(this.parseExpression());
                if (this.peek().type === 'COMMA') {
                    this.advance();
                }
            }
            this.expect('RBRACKET');
            return { type: 'List', elements };
        }

        if (this.peek().type === 'RANGE') {
            this.advance();
            this.expect('LPAREN');
            const start = this.parseExpression();
            this.expect('COMMA');
            const end = this.parseExpression();
            this.expect('RPAREN');
            return { type: 'Range', start, end };
        }

        if (this.peek().type === 'LENGTH') {
            this.advance();
            this.expect('LPAREN');
            const expr = this.parseExpression();
            this.expect('RPAREN');
            return { type: 'Length', expr };
        }

        if (this.peek().type === 'IDENTIFIER') {
            const name = this.advance().value;
            return { type: 'Identifier', name };
        }

        if (this.peek().type === 'LPAREN') {
            this.advance();
            const expr = this.parseExpression();
            this.expect('RPAREN');
            return expr;
        }

        this.error(`Unexpected token: ${this.peek().type}`);
    }
}

// ==================== SYMBOL TABLE ====================
class SymbolTable {
    constructor(parent = null) {
        this.parent = parent;
        this.symbols = {};
        this.scopeType = 'global';
    }

    define(name, type, metadata = {}) {
        if (this.symbols[name]) {
            throw new Error(`Symbol '${name}' already defined in current scope`);
        }
        this.symbols[name] = { type, metadata, defined: true };
    }

    lookup(name) {
        if (this.symbols[name]) {
            return this.symbols[name];
        }
        if (this.parent) {
            return this.parent.lookup(name);
        }
        return null;
    }

    isDefined(name) {
        return this.lookup(name) !== null;
    }

    createChild(scopeType = 'block') {
        const child = new SymbolTable(this);
        child.scopeType = scopeType;
        return child;
    }
}

// ==================== SEMANTIC ANALYZER ====================
class SemanticAnalyzer {
    constructor(ast) {
        this.ast = ast;
        this.symbolTable = new SymbolTable();
        this.errors = [];
        this.warnings = [];
    }

    analyze() {
        try {
            this.analyzeProgram(this.ast);
            if (this.errors.length > 0) {
                throw new Error(this.errors[0]);
            }
            return { success: true, errors: this.errors, warnings: this.warnings };
        } catch (e) {
            return { success: false, errors: [e.message], warnings: this.warnings };
        }
    }

    analyzeProgram(program) {
        program.statements.forEach(stmt => this.analyzeStatement(stmt, this.symbolTable));
    }

    analyzeStatement(stmt, scope) {
        switch (stmt.type) {
            case 'Assignment':
                if (!scope.isDefined(stmt.name)) {
                    scope.define(stmt.name, 'inferred', { initialized: true });
                }
                this.analyzeExpression(stmt.value, scope);
                break;

            case 'Display':
                stmt.args.forEach(arg => this.analyzeExpression(arg, scope));
                break;

            case 'If':
                this.analyzeExpression(stmt.condition, scope);
                const ifScope = scope.createChild('if');
                stmt.thenBranch.forEach(s => this.analyzeStatement(s, ifScope));
                if (stmt.elseBranch) {
                    const elseScope = scope.createChild('else');
                    stmt.elseBranch.forEach(s => this.analyzeStatement(s, elseScope));
                }
                break;

            case 'While':
                this.analyzeExpression(stmt.condition, scope);
                const whileScope = scope.createChild('while');
                stmt.body.forEach(s => this.analyzeStatement(s, whileScope));
                break;

            case 'For':
                scope.define(stmt.variable, 'iterator');
                this.analyzeExpression(stmt.iterable, scope);
                const forScope = scope.createChild('for');
                stmt.body.forEach(s => this.analyzeStatement(s, forScope));
                break;

            case 'Function':
                scope.define(stmt.name, 'function', { params: stmt.params });
                const funcScope = scope.createChild('function');
                stmt.params.forEach(p => funcScope.define(p, 'parameter'));
                stmt.body.forEach(s => this.analyzeStatement(s, funcScope));
                break;

            case 'Append':
                if (!scope.isDefined(stmt.list)) {
                    this.errors.push(`Variable '${stmt.list}' not defined before use`);
                }
                this.analyzeExpression(stmt.value, scope);
                break;

            case 'Remove':
                if (!scope.isDefined(stmt.list)) {
                    this.errors.push(`Variable '${stmt.list}' not defined before use`);
                }
                this.analyzeExpression(stmt.index, scope);
                break;
        }
    }

    analyzeExpression(expr, scope) {
        if (!expr) return;

        switch (expr.type) {
            case 'Identifier':
                if (!scope.isDefined(expr.name)) {
                    this.errors.push(`Variable '${expr.name}' used before definition`);
                }
                break;

            case 'BinaryOp':
                this.analyzeExpression(expr.left, scope);
                this.analyzeExpression(expr.right, scope);
                break;

            case 'UnaryOp':
                this.analyzeExpression(expr.expr, scope);
                break;

            case 'FunctionCall':
                if (!scope.isDefined(expr.name)) {
                    this.errors.push(`Function '${expr.name}' not defined`);
                }
                expr.args.forEach(arg => this.analyzeExpression(arg, scope));
                break;

            case 'List':
                expr.elements.forEach(el => this.analyzeExpression(el, scope));
                break;

            case 'Range':
                this.analyzeExpression(expr.start, scope);
                this.analyzeExpression(expr.end, scope);
                break;

            case 'Length':
                this.analyzeExpression(expr.expr, scope);
                break;

            case 'MethodCall':
                this.analyzeExpression(expr.object, scope);
                expr.args.forEach(arg => this.analyzeExpression(arg, scope));
                break;

            case 'IndexAccess':
                this.analyzeExpression(expr.object, scope);
                this.analyzeExpression(expr.index, scope);
                break;
        }
    }
}

// ==================== OPTIMIZER ====================
class Optimizer {
    constructor(ast) {
        this.ast = ast;
    }

    optimize() {
        this.ast.statements = this.optimizeStatements(this.ast.statements);
        return this.ast;
    }

    optimizeStatements(statements) {
        // Remove dead code (unreachable statements after return)
        const optimized = [];
        for (let i = 0; i < statements.length; i++) {
            optimized.push(this.optimizeStatement(statements[i]));
            if (statements[i].type === 'Return') {
                break; // Dead code after return
            }
        }
        return optimized;
    }

    optimizeStatement(stmt) {
        switch (stmt.type) {
            case 'Assignment':
                return {
                    ...stmt,
                    value: this.optimizeExpression(stmt.value)
                };

            case 'If':
                return {
                    ...stmt,
                    condition: this.optimizeExpression(stmt.condition),
                    thenBranch: this.optimizeStatements(stmt.thenBranch),
                    elseBranch: stmt.elseBranch ? this.optimizeStatements(stmt.elseBranch) : null
                };

            case 'While':
                return {
                    ...stmt,
                    condition: this.optimizeExpression(stmt.condition),
                    body: this.optimizeStatements(stmt.body)
                };

            case 'For':
                return {
                    ...stmt,
                    iterable: this.optimizeExpression(stmt.iterable),
                    body: this.optimizeStatements(stmt.body)
                };

            case 'Function':
                return {
                    ...stmt,
                    body: this.optimizeStatements(stmt.body)
                };

            default:
                return stmt;
        }
    }

    optimizeExpression(expr) {
        if (!expr) return expr;

        switch (expr.type) {
            case 'BinaryOp':
                // Constant folding
                const left = this.optimizeExpression(expr.left);
                const right = this.optimizeExpression(expr.right);

                if (left.type === 'Literal' && right.type === 'Literal') {
                    try {
                        const result = this.evaluateConstant(left.value, expr.op, right.value);
                        return { type: 'Literal', value: result };
                    } catch (e) {
                        // Can't fold, return optimized operands
                    }
                }

                return { ...expr, left, right };

            case 'UnaryOp':
                const innerExpr = this.optimizeExpression(expr.expr);
                if (innerExpr.type === 'Literal') {
                    try {
                        const result = this.evaluateUnary(expr.op, innerExpr.value);
                        return { type: 'Literal', value: result };
                    } catch (e) {
                        // Can't fold
                    }
                }
                return { ...expr, expr: innerExpr };

            case 'List':
                return { ...expr, elements: expr.elements.map(e => this.optimizeExpression(e)) };

            case 'Range':
                return {
                    ...expr,
                    start: this.optimizeExpression(expr.start),
                    end: this.optimizeExpression(expr.end)
                };

            case 'MethodCall':
                return {
                    ...expr,
                    object: this.optimizeExpression(expr.object),
                    args: expr.args.map(a => this.optimizeExpression(a))
                };

            case 'IndexAccess':
                return {
                    ...expr,
                    object: this.optimizeExpression(expr.object),
                    index: this.optimizeExpression(expr.index)
                };

            default:
                return expr;
        }
    }

    evaluateConstant(left, op, right) {
        const opMap = {
            PLUS: () => left + right,
            MINUS: () => left - right,
            MULT: () => left * right,
            DIV: () => left / right,
            MOD: () => left % right,
            EQ: () => left === right,
            NEQ: () => left !== right,
            LT: () => left < right,
            GT: () => left > right,
            LTE: () => left <= right,
            GTE: () => left >= right,
            AND: () => left && right,
            OR: () => left || right
        };

        if (!(op in opMap)) {
            throw new Error(`Unknown operator: ${op}`);
        }

        return opMap[op]();
    }

    evaluateUnary(op, value) {
        const opMap = {
            NOT: () => !value,
            MINUS: () => -value
        };

        if (!(op in opMap)) {
            throw new Error(`Unknown unary operator: ${op}`);
        }

        return opMap[op]();
    }
}

// ==================== CODE GENERATOR ====================
class CodeGenerator {
    constructor(ast) {
        this.ast = ast;
        this.code = [];
        this.indentLevel = 0;
    }

    generate() {
        this.ast.statements.forEach(stmt => this.generateStatement(stmt));
        return this.code.join('\n');
    }

    indent() {
        return '    '.repeat(this.indentLevel);
    }

    generateStatement(stmt) {
        switch (stmt.type) {
            case 'Assignment':
                this.code.push(`${this.indent()}${stmt.name} = ${this.generateExpression(stmt.value)}`);
                break;
            case 'Display':
                const args = stmt.args.map(arg => this.generateExpression(arg)).join(', ');
                this.code.push(`${this.indent()}print(${args})`);
                break;
            case 'Input':
                const prompt = stmt.prompt ? this.generateExpression(stmt.prompt) : '""';
                this.code.push(`${this.indent()}input(${prompt})`);
                break;
            case 'If':
                this.code.push(`${this.indent()}if ${this.generateExpression(stmt.condition)}:`);
                this.indentLevel++;
                stmt.thenBranch.forEach(s => this.generateStatement(s));
                this.indentLevel--;
                if (stmt.elseBranch) {
                    this.code.push(`${this.indent()}else:`);
                    this.indentLevel++;
                    stmt.elseBranch.forEach(s => this.generateStatement(s));
                    this.indentLevel--;
                }
                break;
            case 'While':
                this.code.push(`${this.indent()}while ${this.generateExpression(stmt.condition)}:`);
                this.indentLevel++;
                stmt.body.forEach(s => this.generateStatement(s));
                this.indentLevel--;
                break;
            case 'For':
                this.code.push(`${this.indent()}for ${stmt.variable} in ${this.generateExpression(stmt.iterable)}:`);
                this.indentLevel++;
                stmt.body.forEach(s => this.generateStatement(s));
                this.indentLevel--;
                break;
            case 'Function':
                const params = stmt.params.join(', ');
                this.code.push(`${this.indent()}def ${stmt.name}(${params}):`);
                this.indentLevel++;
                stmt.body.forEach(s => this.generateStatement(s));
                if (!stmt.body.some(s => s.type === 'Return')) {
                    this.code.push(`${this.indent()}return None`);
                }
                this.indentLevel--;
                break;
            case 'Return':
                if (stmt.value) {
                    this.code.push(`${this.indent()}return ${this.generateExpression(stmt.value)}`);
                } else {
                    this.code.push(`${this.indent()}return None`);
                }
                break;
            case 'Import':
                this.code.push(`${this.indent()}import ${stmt.module} as ${stmt.alias}`);
                break;
            case 'FileOpen':
                const filename = this.generateExpression(stmt.filename);
                const mode = this.generateExpression(stmt.mode);
                this.code.push(`${this.indent()}${stmt.variable} = open(${filename}, ${mode})`);
                break;
            case 'Read':
                this.code.push(`${this.indent()}${stmt.file}.read()`);
                break;
            case 'Write':
                const content = this.generateExpression(stmt.content);
                this.code.push(`${this.indent()}${stmt.file}.write(${content})`);
                break;
            case 'Close':
                this.code.push(`${this.indent()}${stmt.file}.close()`);
                break;
            case 'Append':
                const value = this.generateExpression(stmt.value);
                this.code.push(`${this.indent()}${stmt.list}.append(${value})`);
                break;
            case 'Remove':
                const index = this.generateExpression(stmt.index);
                this.code.push(`${this.indent()}${stmt.list}.pop(${index})`);
                break;
            default:
                throw new Error(`Unknown statement type: ${stmt.type}`);
        }
    }

    generateExpression(expr) {
        if (!expr) return '';

        switch (expr.type) {
            case 'Literal':
                if (typeof expr.value === 'string') {
                    return `"${expr.value.replace(/"/g, '\\"')}"`;
                }
                return String(expr.value);
            case 'Identifier':
                return expr.name;
            case 'BinaryOp':
                const left = this.generateExpression(expr.left);
                const right = this.generateExpression(expr.right);
                const opMap = {
                    PLUS: '+', MINUS: '-', MULT: '*', DIV: '/', MOD: '%',
                    EQ: '==', NEQ: '!=', LT: '<', GT: '>', LTE: '<=', GTE: '>=',
                    AND: 'and', OR: 'or'
                };
                return `(${left} ${opMap[expr.op]} ${right})`;
            case 'UnaryOp':
                const opUnaryMap = { NOT: 'not', MINUS: '-' };
                return `${opUnaryMap[expr.op]} ${this.generateExpression(expr.expr)}`;
            case 'List':
                const elements = expr.elements.map(e => this.generateExpression(e)).join(', ');
                return `[${elements}]`;
            case 'Range':
                const start = this.generateExpression(expr.start);
                const end = this.generateExpression(expr.end);
                return `range(${start}, ${end})`;
            case 'Length':
                return `len(${this.generateExpression(expr.expr)})`;
            case 'FunctionCall':
                const args = expr.args.map(arg => this.generateExpression(arg)).join(', ');
                return `${expr.name}(${args})`;
            case 'MethodCall':
                const obj = this.generateExpression(expr.object);
                const methodArgs = expr.args.map(arg => this.generateExpression(arg)).join(', ');
                return `${obj}.${expr.method}(${methodArgs})`;
            case 'PropertyAccess':
                return `${this.generateExpression(expr.object)}.${expr.property}`;
            case 'IndexAccess':
                const object = this.generateExpression(expr.object);
                const index = this.generateExpression(expr.index);
                return `${object}[${index}]`;
            default:
                throw new Error(`Unknown expression type: ${expr.type}`);
        }
    }
}

// ==================== COMPILER ====================
function compile(source) {
    try {
        // Phase 1: Lexical Analysis
        const lexer = new Lexer(source);
        const tokens = lexer.tokenize();

        // Phase 2: Syntax Analysis
        const parser = new Parser(tokens);
        const ast = parser.parse();

        // // Phase 3: Semantic Analysis
        const semanticAnalyzer = new SemanticAnalyzer(ast);
        const semanticResult = semanticAnalyzer.analyze();
        
        if (!semanticResult.success) {
            return { success: false, code: null, error: semanticResult.errors[0] };
        }

        // Phase 4: Optimization
        const optimizer = new Optimizer(ast);
        const optimizedAst = optimizer.optimize();

        // Phase 5: Code Generation
        const generator = new CodeGenerator(optimizedAst);
        const generatedCode = generator.generate();

        return { 
            success: true, 
            code: generatedCode, 
            error: null,
            warnings: semanticResult.warnings 
        };
    } catch (e) {
        return { success: false, code: null, error: e.message };
    }
}
